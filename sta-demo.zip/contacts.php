<!DOCTYPE html>

<html lang="en-US" class="chrome chrome113" style="overflow-x: hidden;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

   <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files-->
   
    <link rel="stylesheet" href="assets/css/owl-slider.css">
    <link rel="stylesheet" href="assets/css/owl.css">

<script type="text/javascript" async src="assets/js/js"></script>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<title>Industrial Concrete Flooring, Laser Screed Concrete Flooring, CopperHead Concrete Flooring, Large Line Laser Screed S240 Flooring, Laying in Situ Concrete Floors, Colors to Concrete floors, India, Asia</title>
<meta name="robots" content="index, follow">

<link rel="preload" as="style" href="assets/css/css">
<link rel="stylesheet" href="assets/css/css" media="all" onload="this.media=&#39;all&#39;">

<noscript>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Big%20Shoulders%20Inline%20Display%3A400%7CMoul%3A400%2C700%7CLobster%3A400%2C700%7CBig%20Shoulders%20Inline%20Display%3A400%7CMoul%3A400%2C700%7CLobster%3A400%2C700%7CSource%20Sans%20Pro%3A300%2C400%2C700%7CBebas%20Neue%3A400&#038;display=swap" />
</noscript>

<link rel="stylesheet" href="assets/css/sta.css" media="all" data-minify="1">
	<meta name="description" content="Concrete Flooring Company">
	<meta property="og:locale" content="en_US">


<link rel="dns-prefetch" href="https://fonts.googleapis.com/">
<link href="https://fonts.gstatic.com/" crossorigin="" rel="preconnect">


<style id="wp-block-library-inline-css">.has-text-align-justify{text-align:justify;}</style>



<script src="assets/js/jquery.min.js.download" id="jquery-core-js" defer></script>
<script data-minify="1" src="assets/js/jquery-migrate.min.js.download" id="jquery-migrate-js" defer></script>
<script data-minify="1" src="assets/js/imagesloaded.min.js.download" id="imagesloaded-js" defer></script>

<style id="wp-custom-css">
/*-------------------------------
            TYPOGRAPHY 
--------------------------------*/

body p, 
.entry-content p, 
.entry-content ul li,  
.entry-content ul,  
.entry-content a, 
.pp-sub-heading p {

}
a:focus {
    outline: none;
}
div#full-col li a {
    display: inline-block;
}
@media (max-width:768px){
	.fl-builder-content[data-overlay="1"]:not(.fl-theme-builder-header-sticky):not(.fl-builder-content-editing){
		position:relative;
	}
}
/*--------------------------------
            HEADER 
---------------------------------*/
/*---
  Media queries? Y/N
---*/



/*-------------------------------
            NAVIGATION
--------------------------------*/
/*---
  Media queries? Y/N
---*/
.uabb-creative-menu .menu.uabb-creative-menu-horizontal ul.sub-menu > li a span.uabb-menu-toggle {
    float: none;
}
input[type=text], input[type=password], input[type=email], input[type=tel], input[type=date], input[type=month], input[type=week], input[type=time], input[type=number], input[type=search], input[type=url], textarea{
	color: #fff !important;
	background-color: #ccc !important;
}

/*--------------------------------
            BUTTONS
----------------------------------*/
/*---
  Media queries? Y/N
---*/

a.button, 
span.fl-button-text, 
span.uabb-button-text.uabb-creative-button-text, 
.gform_button.button, 
a.fl-button {

}

.fl-builder-content .fl-node-5fc7630aaef4f .fl-form-button a.fl-button, .fl-builder-content .fl-node-5fc7630aaef4f .fl-form-button a.fl-button:visited, .fl-builder-content .fl-node-5fc7630aaef4f .fl-form-button a.fl-button *, .fl-builder-content .fl-node-5fc7630aaef4f .fl-form-button a.fl-button:visited * {
 
    text-transform: uppercase;
}

/*----------------------------------
            FOOTER
---------------------------------*/
/*---
  Media queries? Y/N
---*/
footer ul li a {
  display: inline-block;
}

/*------------------------------
            BB MODULES
---------------------------------*/

/*---
  MODULE NAME
  Description of section
  Media queries? Y/N
---*/


/*------------------------------
            PAGE SPECIFIC 
---------------------------------*/

/*---
  PAGE NAME
  Description of section
  Media queries? Y/N
---*/



/*-------------------------------
        LARGE SCREENS ONLY
---------------------------------*/

@media screen and (min-width: 769px){ 


}


/*-------------------------------
        LAPTOP SCREEN - 1366
---------------------------------*/

@media only screen and (min-width:1250px) and (max-width:1366px){ 
div#h2-col > .fl-col-content {
   
    margin-right: 20px;
    margin-left: 20px;
}

}


/*-------------------------------
      IPAD PRO SCREENS - 1024
---------------------------------*/

@media screen and (max-width: 1024px){ 


}


/*--------------------------------
    TABLET SCREENS AND SMALLER
--------------------------------*/

@media screen and (max-width: 768px){
.fl-builder-content[data-overlay="1"]:not(.fl-theme-builder-header-sticky) {
  position: relative;
}
.fl-col-small {
  max-width: 100%;
}
 .uabb-info-list-icon{
    margin-bottom: 0px !important;
}
.fl-node-5fc60677641e8 > .fl-row-content-wrap {
    background-color: #0a0a0a !important;
}
	div#serve ul.uabb-info-list-wrapper.uabb-info-list-left li {
    width: 45% !important;
    display: inline-block !important;
    vertical-align: top;

}
	div#img-hide > .fl-col-content{
		background-image: url();
	}
	.fl-builder-content .hero-text .fl-rich-text, .fl-builder-content .hero-text .fl-rich-text :not(b, strong) {
    font-size: 40px;
}
}


/*-------------------------------
        MOBILE SCREENS ONLY
---------------------------------*/

@media screen and (max-width: 480px){ 
div#full-col {
    width: 100% !important;
}
div#serve ul.uabb-info-list-wrapper.uabb-info-list-left li {
    width: 100% !important;
    display: inline-block !important;
    vertical-align: top;

}

input#gform_submit_button_2 {
    line-height: 1.2;
    margin-bottom: 0px;
}
	.fl-builder-content .hero-text .fl-rich-text, .fl-builder-content .hero-text .fl-rich-text :not(b, strong) {
    font-size: 48px;
}

}


.archive.post-type-archive .fl-page-content {background-color: #333;padding-top:120px;}	

/* gallery */
div.gal {
  float:left;
  padding: 5px;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin: 25px;
}
.fl-post img[class*="wp-image-"], .fl-post img.alignnone, .fl-post img.alignleft, .fl-post img.aligncenter, .fl-post img.alignright {
    max-width: 100%;
    height: 250px;
}

input[type=text], input[type=password], input[type=email], input[type=tel], input[type=date], input[type=month], input[type=week], input[type=time], input[type=number], input[type=search], input[type=url], textarea {
    color: #0b0b0b !important;
    background-color: #ccc !important;
    text-align:left;
}
</style>

	

<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Big%20Shoulders%20Inline%20Display%3A400%7CMoul%3A400%2C700%7CLobster%3A400%2C700%7CBig%20Shoulders%20Inline%20Display%3A400%7CMoul%3A400%2C700%7CLobster%3A400%2C700%7CSource%20Sans%20Pro%3A300%2C400%2C700%7CBebas%20Neue%3A400&#038;display=swap" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Big%20Shoulders%20Inline%20Display%3A400%7CMoul%3A400%2C700%7CLobster%3A400%2C700%7CBig%20Shoulders%20Inline%20Display%3A400%7CMoul%3A400%2C700%7CLobster%3A400%2C700%7CSource%20Sans%20Pro%3A300%2C400%2C700%7CBebas%20Neue%3A400&#038;display=swap" media="print" onload="this.media='all'" />
        

<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;

  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } 
else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; 


}
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
document.form1.verif_box.focus();
MM_validateForm1();

}
//-->
</script>


<script language="JavaScript" type="text/JavaScript">
function MM_validateForm1() {



	var emailid = document.form1.from.value;
	
	var mobile = document.form1.mobile.value;
    var stripped = mobile.replace(/[\(\)\.\-\ ]/g, '');    
	
	var letters = /^[A-Za-z ]+$/;  
	var numbers = /^[0-9]+$/;  

	
    if (document.form1.name.value == "")
	{
		alert ('Enter Name');
		document.form1.name.focus();
		return false;
	}
     else if(!(document.form1.name.value.match(letters)))
      {  
      alert('Please input alphabet characters only');  
	  document.form1.name.focus();
      return false;  
      }
    else if (document.form1.projectnm.value == "")
	{
		alert ('Enter Project Name');
		document.form1.projectnm.focus();
		return false;
	}
    else if (document.form1.projectadd.value == "")
	{
		alert ('Enter Project Address');
		document.form1.projectadd.focus();
		return false;
	}
   else if (document.form1.interested.value == "")
	{
		alert ('Enter "I am Interested In" field');
		document.form1.interested.focus();
		return false;
	}
     else if(!(document.form1.name.value.match(letters)))
      {  
      alert('Please input alphabet characters only');  
      return false;  
      }
	
    else if (mobile == "") 
   {
        alert ("Enter a Mobile number.");
        document.form1.mobile.focus();
		return false;
    } 
	else if (isNaN(parseInt(stripped))) 
	{	
        alert ("The Mobile number contains illegal characters.\n");
        document.form1.mobile.focus();	
		return false;
    } 
	else if (stripped.length > 15) 
	{
	
        alert ("The Mobile number length should be less than or equal to 15 digit.\n");
        document.form1.mobile.focus();	
		return false;
    }
   	
	
	else if (emailid != " " || emailid != null)
	{
		if(!isMail(emailid,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_@."))
		{
			alert ('Enter Email');
			document.form1.from.focus();
			return false;
		}
	}
	return true;
}

function isMail(string,text)
{
	var i,txt;
	var n=string.length;
	for(i=0;i<n;i++)
	{
		txt=string.charAt(i);
		if(text.indexOf(txt)==-1)
			return false;
	}

	var x=string.indexOf('@');
	if(x==0 || x==n-1 || x==-1 )
	{
		return false;
	}
	/* checking for @. sign */
	if(x+1==string.indexOf('.')) 
	{
		return false;
	}
		if(x-1==string.indexOf('.')) 
	{
		return false;
	}

	/* checking for  more then one @ sign 	*/
	var y=string.indexOf('@',x+1);
	if(y!=-1)
	{
		return false;
	}	
	/* checking for '.' operator */
	x=string.indexOf('.');
	if(x==0 || x==n-1)
	{
		return false;
	}
	x=string.indexOf('.',x+1);
	if(x-1==string.indexOf('@') ||x+1==string.indexOf('@'))
	{
		return false;
	}
	return true;
}

</script>

 </head>

<body class="home page-template-default page page-id-5 wp-custom-logo theme-bb-theme fl-builder fl-theme-builder-header fl-theme-builder-header-header fl-theme-builder-footer fl-theme-builder-footer-footer fl-framework-bootstrap fl-preset-default fl-full-width fl-scroll-to-top fl-search-active fl-builder-breakpoint-default" itemscope="itemscope" itemtype="https://schema.org/WebPage">

<header class="fl-builder-content fl-builder-content-8 fl-builder-global-templates-locked" data-post-id="8" data-type="header" data-sticky="1" data-sticky-on="" data-sticky-breakpoint="medium" data-shrink="0" data-overlay="1" data-overlay-bg="transparent" data-shrink-image-height="50px" role="banner" itemscope="itemscope" itemtype="http://schema.org/WPHeader">

<div id="header-row" class="fl-row fl-row-full-width fl-row-bg-color fl-node-5fc60677641e8" data-node="5fc60677641e8">
<div class="fl-row-content-wrap">
	<div class="uabb-row-separator uabb-top-row-separator">
</div>
	<div class="fl-row-content fl-row-fixed-width fl-node-content" style="position: relative;">
		
	<div class="fl-col-group fl-node-5fc6067772ce5 fl-col-group-equal-height fl-col-group-align-center fl-col-group-custom-width" data-node="5fc6067772ce5">
	<div class="fl-col fl-node-5fc6067772f6a fl-col-small fl-col-small-full-width" data-node="5fc6067772f6a">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-pp-image fl-node-5fc606af28a79" data-node="5fc606af28a79">
	<div class="fl-module-content fl-node-content">
	<div class="pp-photo-container">
	<div class="pp-photo pp-photo-align-left pp-photo-align-responsive-default" itemscope="" itemtype="http://schema.org/ImageObject">
	<div class="pp-photo-content">
	<div class="pp-photo-content-inner">
	<a href="#" target="_self" itemprop="url"><img decoding="async" src="assets/images/sta-logo.png" alt="STA PNG" itemprop="image"  style="max-width:97%"/></noscript>
	<div class="pp-overlay-bg"></div></a>
	</div>
	</div>
	</div>
</div>
	</div>
</div>
</div>
</div>
	<div class="fl-col fl-node-5fc6067772f72" data-node="5fc6067772f72">
	<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-uabb-advanced-menu fl-node-5fc6074692938" data-node="5fc6074692938">
	<div class="fl-module-content fl-node-content">
	<div class="uabb-creative-menu
	 uabb-creative-menu-accordion-collapse	uabb-menu-default">
	<div class="uabb-creative-menu-mobile-toggle-container"><div class="uabb-creative-menu-mobile-toggle hamburger" tabindex="0"><div class="uabb-svg-container"><svg version="1.1" class="hamburger-menu" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" viewBox="0 0 50 50">
<rect class="uabb-hamburger-menu-top" width="50" height="10"></rect>
<rect class="uabb-hamburger-menu-middle" y="20" width="50" height="10"></rect>
<rect class="uabb-hamburger-menu-bottom" y="40" width="50" height="10"></rect>
</svg>
</div></div></div>
<div class="uabb-clear"></div>

<ul id="menu-main" class="menu uabb-creative-menu-horizontal uabb-toggle-none" style="float:right; background-color:#424242; opacity: 0.9;border-radius: 15px;border: 0px solid #000; text-align:right;width:550px; height:40px;">

	
 	<li id="menu-item-703" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="index.html"><span class="menu-item-text"><strong>Home</strong></span></a></li>
    <li id="menu-item-701" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="profile.html"><span class="menu-item-text"><strong>Profile</strong></span></a></li>                   
	  <li id="menu-item-702" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home uabb-has-submenu uabb-creative-menu uabb-cm-style"><div class="uabb-has-submenu-container"><a href="services.html"><span class="menu-item-text"><strong><strong>SERVICES</strong></strong></span></a></div>
		<ul class="sub-menu">
	<li id="menu-item-819" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="Turnkey-Floor-Solutions.html"><span class="menu-item-text">Turnkey Floor Solutions</span></a></li>		
		<li id="menu-item-821" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="Laser-Screed-Floor-Solutions.html"><span class="menu-item-text">Laser Screed Floor Solutions</a></li>
<li id="menu-item-821" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="SFRC-and-Rebar-Floor.html"><span class="menu-item-text">SFRC and Rebar Floor Solutions</a></li>
<li id="menu-item-821" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="Speciality-Floor-Solutions.html"><span class="menu-item-text">Speciality Floor Solutions</a></li>
		

	</ul>
	</li>

	<li id="menu-item-946" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home uabb-creative-menu uabb-cm-style"><a href="#"><span class="menu-item-text"><strong>Projects</strong></span></a></li>
	<li id="menu-item-704" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="gallery.html"><span class="menu-item-text"><strong>Gallery</strong></span></a></li>

	<li id="menu-item-706" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-5 current_page_item uabb-creative-menu uabb-cm-style"><a href="contacts.php"><span class="menu-item-text"><strong>Contact Us</strong></span></a></li>
</ul>
</div>

<div class="uabb-creative-menu-mobile-toggle-container">
<div class="uabb-creative-menu-mobile-toggle hamburger" tabindex="0">
<div class="uabb-svg-container"><svg version="1.1" class="hamburger-menu" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" viewBox="0 0 50 50">
<rect class="uabb-hamburger-menu-top" width="50" height="10"></rect>
<rect class="uabb-hamburger-menu-middle" y="20" width="50" height="10"></rect>
<rect class="uabb-hamburger-menu-bottom" y="40" width="50" height="10"></rect>
</svg>
</div></div></div>

<div class="uabb-creative-menu	 uabb-creative-menu-accordion-collapse	off-canvas">
<div class="uabb-clear"></div>
<div class="uabb-off-canvas-menu uabb-menu-right">
<div class="uabb-menu-close-btn">×</div>

<ul id="menu-main-1" class="menu uabb-creative-menu-horizontal uabb-toggle-none">

<li id="menu-item-703" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="index.html"><span class="menu-item-text"><strong>Home</strong></span></a></li>
<li id="menu-item-701" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-5 current_page_item uabb-creative-menu uabb-cm-style"><a href="profile.html"><span class="menu-item-text"><strong>profile</strong></span></a></li>
  <li id="menu-item-702" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home uabb-has-submenu uabb-creative-menu uabb-cm-style"><div class="uabb-has-submenu-container"><a href="services.html"><span class="menu-item-text"><strong><strong>SERVICES</strong></strong></span></a></div>
	<ul class="sub-menu">
<li id="menu-item-819" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="Turnkey-Floor-Solutions.html"><span class="menu-item-text">Turnkey Floor Solutions</span></a></li>		
		<li id="menu-item-821" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="Laser-Screed-Floor-Solutions.html"><span class="menu-item-text">Laser Screed Floor Solutions</span></a></li>
<li id="menu-item-821" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="SFRC-and-Rebar-Floor.html"><span class="menu-item-text">SFRC & Rebar Floor Solutions</span></a></li>
<li id="menu-item-821" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="Speciality-Floor-Solutions.html"><span class="menu-item-text">Speciality Floor Solutions</a></li>
		
	</ul>
</li>

<li id="menu-item-946" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home uabb-creative-menu uabb-cm-style"><a href="#"><span class="menu-item-text"><strong>Projects</strong></span></a></li>
	<li id="menu-item-704" class="menu-item menu-item-type-post_type menu-item-object-page uabb-creative-menu uabb-cm-style"><a href="gallery.html"><span class="menu-item-text"><strong>Gallery</strong></span></a></li>

	<li id="menu-item-706" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-5 current_page_item uabb-creative-menu uabb-cm-style"><a href="contacts.php"><span class="menu-item-text"><strong>Contact Us</strong></span></a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</header>

<div class="uabb-js-breakpoint" style="display: none;"></div>	<div id="fl-main-content" class="fl-page-content" itemprop="mainContentOfPage" role="main">

		
<div class="fl-content-full container">
	<div class="row">
		<div class="fl-content col-md-12">
			<article class="fl-post post-5 page type-page status-publish hentry" id="fl-post-5" itemscope="itemscope" itemtype="https://schema.org/CreativeWork">

			<div class="fl-post-content clearfix" itemprop="text">
		<div class="fl-builder-content fl-builder-content-5 fl-builder-content-primary fl-builder-global-templates-locked" data-post-id="5">
<div class="fl-row fl-row-full-width fl-row-bg-photo fl-node-6344406bee540 fl-row-custom-height fl-row-align-center fl-row-bg-overlay fl-visible-desktop-medium" data-node="6344406bee540">

<div class="fl-row-content-wrap1">
	<div class="uabb-row-separator uabb-top-row-separator"></div>
	<div class="fl-row-content fl-row-fixed-width fl-node-content">
	<div class="fl-col-group fl-node-6344406bee5ef fl-col-group-equal-height fl-col-group-align-center fl-col-group-custom-width" data-node="6344406bee5ef">
	<div class="fl-col fl-node-6344406bee5f0" data-node="6344406bee5f0">
	<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-heading fl-node-6344406bee5f1" data-node="6344406bee5f1">
	<div class="fl-module-content fl-node-content">
	<h1 class="fl-heading">	<span class="fl-heading-text"> .</span></h1>
	</div>
</div>
<div style="height:250px; text-align: left;" class="fl-module fl-module-rich-text fl-node-6344406bee5f2" data-node="6344406bee5f2">
<h1 class="fl-heading">	<span class="fl-heading-text"> Our Projects </span></h1>
</div>


</div>
</div>
</div>
</div>
</div>
</div>

<div class="fl-row fl-row-full-width fl-row-bg-none fl-node-k7p2sohfne8l fl-visible-mobile" data-node="k7p2sohfne8l">
	<div class="fl-row-content-wrap">
		<div class="uabb-row-separator uabb-top-row-separator"></div>
		<div class="fl-row-content fl-row-fixed-width fl-node-content">
		<div class="fl-col-group fl-node-59m4dqie6hac" data-node="59m4dqie6hac">
		<div class="fl-col fl-node-lbedvi3xcpz8" data-node="lbedvi3xcpz8">
		<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-photo fl-node-axhngtzvero5" data-node="axhngtzvero5">
		<div class="fl-module-content fl-node-content">
		<div class="fl-photo fl-photo-align-center" itemscope="" itemtype="https://schema.org/ImageObject">
		<div class="fl-photo-content fl-photo-img-jpg">
		<img decoding="async" src="assets/images/contact-header.jpg" alt="DSC_3370-Edit-2" itemprop="image" height="1080" width="1647" title="DSC_3370-Edit-2"  class="fl-photo-img wp-image-575 size-full no-lazyload">
		</div>
	</div>
	</div>
</div>

<div><h1 style="text-align:center; color:#fb8423;">We Deliver <br> FASTER. FLATTER. FLOORS.™ </h1></div>


</div>
</div>
	</div>
		</div>
	</div>
</div>
<div style="background-color:#000; color:#fff; text-align:center;font-weight:500;" class="fl-row fl-row-full-width fl-row-bg-none fl-node-633df60e2fa3d" data-node="633df60e2fa3d">

	<div class="fl-row-content-wrap">
	<div class="uabb-row-separator uabb-top-row-separator"></div>
	<div class="fl-row-content fl-row-fixed-width fl-node-content">
	<div class="fl-col-group fl-node-633df60e2fa45" data-node="633df60e2fa45">
	<div class="fl-col fl-node-633df60e2fa46" data-node="633df60e2fa46">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-heading fl-node-633df60e2fa47" data-node="633df60e2fa47">
	
</div>
<div class="fl-module fl-module-rich-text fl-node-633df60e2fa48" data-node="633df60e2fa48">
<div class="fl-module-content fl-node-content">
<div class="fl-rich-text">

<div class="row">

<div style="background-color:#000;" class="col-sm-4 col-md-4">
<h3>Address:</h3> 
<div style="width:100%; float:left; margin-right:0px;background-color:#000;" >

<p style="font-size:15px;"><b style="color:red;">REGISTER ADDRESS:</b><br>
233, Kakade Plaza, 
Opp. Kakade City,
Karvenagar, Pune - 411 052.
Maharastra State, India</p>

<p style="font-size:15px;"><b style="color:red;">GEORGIA ADDRESS:</b><br>
AAA international LLC 
2, Delisi Asatiani
Tbilisi, Georgia<br>
<span style="color:blue;">GSM:</span> +995558590195</p>

<p style="font-size:15px;">
<b style="color:red;">CALL US:</b ><br>
<span style="color:blue;">Phone :</span > +91-20-25209053<br>
<span style="color:blue;">Mobile :</span >
<a href="tel:+91942-203-3554"> +91-9422033554,</a><a href="tel:+91982-202-8193">9822028193</a><br />
<span style="color:blue;">E-mail us:</span ><br>
<a href = "mailto:teksun@staflooring.com">teksun@staflooring.com</a> <br />
<span style="color:blue;">visit us:</span ><br>
<a href = "http://www.staflooring.com">www.staflooring.com</a></p><br />
</div>
</div>

<div align="left" class="col-sm-4 col-md-4" style="padding:20px;">

<h3 class="heading_c">Google Map</h3>                  

<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7567.851153783476!2d73.812858!3d18.48703!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bfdc0b6197d9%3A0x57c8f1f195ac55cf!2sSTA%20Concrete%20Flooring%20Solutions!5e0!3m2!1sen!2sin!4v1691207760743!5m2!1sen!2sin" width="600" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

</div>



<div align="left" class="col-sm-4 col-md-4" style="background-color:#000;">
<p style="text-align:left">

<h3 class="heading_c">Enquiry Form</h3>        
<form action="mailer.php" method="post" name="form1" id="form1" 
style="margin-left:0px;  font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px;background-color:#000; text-align:left" onsubmit="MM_validateForm('verif_box','','R'); return document.MM_returnValue">

Your Name:<br />
<input name="name" type="text" id="name" style="border:1px solid #CCCCCC; width:300px; height:28px; margin-bottom:10px; font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px;background-color:#fbdabc;text-align:left" value="<?php echo $_GET['name'];?>"/>


Project Name:<br />
<input name="projectnm" type="text" id="projectnm" style="padding:2px; border:1px solid #CCCCCC; width:300px; height:28px; margin-bottom:10px;text-align:left; font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px;" value="<?php echo $_GET['projectnm'];?>"/>


Project Address:<br />
<input name="projectadd" type="text" id="projectadd" style="padding:2px; border:1px solid #CCCCCC; width:300px; height:28px; margin-bottom:10px;text-align:left; font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px;" value="<?php echo $_GET['projectadd'];?>"/>


Phone / Mobile:<br />
<input name="mobile" type="text" id="mobile" style="border:1px solid #CCCCCC; width:300px; height:28px; margin-bottom:10px; font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px;background-color:#fbdabc;text-align:left" value="<?php echo $_GET['mobile'];?>"/>

Your e-mail:<br />
<input name="from" type="text" id="from" style="border:1px solid #CCCCCC; width:300px; height:28px; margin-bottom:10px;text-align:left; font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px;" value="<?php echo $_GET['from'];?>"/>


Type verification image:<br />
<input name="verif_box" type="text" id="verif_box" style=" border:1px solid #CCCCCC; width:300px; height:28px; margin-bottom:10px;text-align:left; font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px;text-align:left; color:#000;"/>
<img src="verificationimage.php?<?php echo rand(0,9999);?>" alt="verification image, type it in the box" width="50" height="24" align="absbottom" /><br />


<!-- if the variable "wrong_code" is sent from previous page then display the error field -->
<?php if(isset($_GET['wrong_code'])){?>
<div style="border:1px solid #990000; background-color:#D70000; color:#000; padding:4px; padding-left:6px;width:295px;margin-bottom:10px;">Wrong verification code</div>
<?php ;}?>

I am Interested In:<br />
<textarea name="interested" cols="6" rows="3" id="interested" style="padding:2px; border:1px solid #CCCCCC; width:300px; height:50px; font-family:Verdana, Arial, Helvetica, sans-serif; color:#000; font-size:11px;"><?php echo $_GET['interested'];?></textarea>


Comments:<br />
<textarea name="message" cols="6" rows="3" id="message" style="padding:2px; border:1px solid #CCCCCC; width:300px; height:50px; font-family:Verdana, Arial, Helvetica, sans-serif; color:#000; font-size:11px;"><?php echo $_GET['message'];?></textarea>


<input name="Submit" type="submit" style="margin-top:10px; display:block; border:1px solid #000000; width:130px; height:25px;font-family:Verdana, Arial, Helvetica, sans-serif; font-size:15px; padding-left:2px; padding-right:2px; padding-top:0px; padding-bottom:2px; line-height:14px; color:#fff; background-color:#ff7b00;" value="Send Message"/>
</form></p>
<br>
</div>

</div>

</div>
</div>
</div>
</div>
	</div>


		</div>
	</div>
</div>






<div class="fl-row fl-row-full-width fl-row-bg-none fl-node-633df60e2fa3d" data-node="633df60e2fa3d">
	<div class="fl-row-content-wrap"  style="background-color:#000">
		<div class="uabb-row-separator uabb-top-row-s
        eparator">
</div>
						<div class="fl-row-content fl-row-fixed-width fl-node-content">
		
<div class="fl-col-group fl-node-633df60e2fa45" data-node="633df60e2fa45"  style="background-color:#000">
			<div class="fl-col fl-node-633df60e2fa46" data-node="633df60e2fa46">
	<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-heading fl-node-633df60e2fa47" data-node="633df60e2fa47">
	<div class="fl-module-content fl-node-content">
		<h2 class="fl-heading">
		<span class="fl-heading-text"  style="color:#fff">Our Clients</span>
	</h2>
	</div>
</div>
<div class="fl-module fl-module-rich-text" data-node="633df60e2fa48">
	<div class="fl-module-content fl-node-content">
		<div class="fl-rich-text">
	<p style="text-align:justify">
    
    <section class="our-courses" id="courses">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-12">
          <div class="owl-courses-item owl-carousel">
            <div class="item"><img src="assets/images/L&T.jpg" alt="Course One"></div>
            <div class="item"> <img src="assets/images/bajaj.jpg" alt="Course Two"> </div>
            <div class="item"><img src="assets/images/eicher-logo.jpg" alt=""> </div>
            <div class="item"><img src="assets/images/p&g.jpg" alt="">
            </div>
            <div class="item"> <img src="assets/images/coca-cola-logo.jpg" alt=""> </div>
            <div class="item"><img src="assets/images/dr-reddy-logo.jpg" alt=""> </div>
            <div class="item"><img src="assets/images/Mahindra-Logo.jpg" alt=""></div>
           
            <div class="item"><img src="assets/images/pepsi.jpg" alt=""></div>
           
            <div class="item"><img src="assets/images/volkswagen.jpg" alt=""> </div>
        
        </div>
      </div>
    </div>
  </section>

<script src="assets/js/isotope.min.js"></script> 
<script src="assets/js/owl-carousel.js"></script>
<script src="assets/js/custom.js"></script></p>

        </div>
	</div>
</div>
</div>
</div>
	</div>


		
	</div>
		</div>
	</div>
</div>

<div class="uabb-js-breakpoint" style="display: none;"></div>	</div><!-- .fl-post-content -->
	
</article>

<!-- .fl-post -->
		</div>
	</div>
</div>


	</div><!-- .fl-page-content -->
	<footer class="fl-builder-content fl-builder-content-11 fl-builder-global-templates-locked" data-post-id="11" data-type="footer" itemscope="itemscope" itemtype="http://schema.org/WPFooter"><div id="footer3body" class="fl-row fl-row-full-width fl-row-bg-color fl-node-5fc6358d8db4e" data-node="5fc6358d8db4e">
	<div class="fl-row-content-wrap"  style="background-color:#333">
		<div class="uabb-row-separator uabb-top-row-separator">
</div>
						<div class="fl-row-content fl-row-fixed-width fl-node-content">
		
<div class="fl-col-group fl-node-5fc6358d8db4f fl-col-group-equal-height fl-col-group-align-top fl-col-group-custom-width" data-node="5fc6358d8db4f">
			<div id="full-col" class="fl-col fl-node-5fc6358d8db55 fl-col-small fl-col-small-full-width" data-node="5fc6358d8db55">
	<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-rich-text fl-node-633ddab692170" data-node="633ddab692170">
	<div class="fl-module-content fl-node-content">
		<div class="fl-rich-text">
	<p>Contact us!</p>
</div>
	</div>
</div>
<div class="fl-module fl-module-info-list fl-node-5fc6358d8db66 footerinfo" data-node="5fc6358d8db66">
	<div class="fl-module-content fl-node-content">
		
<div class="uabb-module-content uabb-info-list">
	<ul class="uabb-info-list-wrapper uabb-info-list-left">
		<li class="uabb-info-list-item info-list-item-dynamic0"><div class="uabb-info-list-content-wrapper fl-clearfix uabb-info-list-left"><div class="uabb-info-list-icon info-list-icon-dynamic0"><div class="uabb-module-content uabb-imgicon-wrap">				<span class="uabb-icon-wrap">
			<span class="uabb-icon">
				<i class="fas fa-map-marker-alt"></i>
			</span>
		</span>
	
		</div></div><div class="uabb-info-list-content uabb-info-list-left info-list-content-dynamic0"><span class="uabb-info-list-title"></span><div class="uabb-info-list-description uabb-text-editor info-list-description-dynamic0"><p style="text-align: left;">233, Kakade Plaza, Opp. Kakade City, Karvenagar, Pune - 411 052. Maharastra State, India</p>
		</div></div></div><div class="uabb-info-list-connector uabb-info-list-left"></div></li><li class="uabb-info-list-item info-list-item-dynamic1"><div class="uabb-info-list-content-wrapper fl-clearfix uabb-info-list-left"><div class="uabb-info-list-icon info-list-icon-dynamic1"><div class="uabb-module-content uabb-imgicon-wrap">				<span class="uabb-icon-wrap">
			<span class="uabb-icon">
				<i class="fa fa-phone"></i>
			</span>
		</span>
	
		</div></div><div class="uabb-info-list-content uabb-info-list-left info-list-content-dynamic1"><span class="uabb-info-list-title"></span><div class="uabb-info-list-description uabb-text-editor info-list-description-dynamic1">
		  +91-9422033554, 9822028193
		  </div></div></div><div class="uabb-info-list-connector uabb-info-list-left"></div></li><li class="uabb-info-list-item info-list-item-dynamic2"><div class="uabb-info-list-content-wrapper fl-clearfix uabb-info-list-left"><div class="uabb-info-list-icon info-list-icon-dynamic2"><div class="uabb-module-content uabb-imgicon-wrap">				<span class="uabb-icon-wrap">
			<span class="uabb-icon">
				<i class="fas fa-envelope"></i>
			</span>
		</span>
	
		</div></div><div class="uabb-info-list-content uabb-info-list-left info-list-content-dynamic2"><span class="uabb-info-list-title"></span><div class="uabb-info-list-description uabb-text-editor info-list-description-dynamic2"><p><a href="mailto:teksun@staflooring.com">teksun@staflooring.com
</a></p></div></div></div><div class="uabb-info-list-connector uabb-info-list-left"></div></li>	</ul>
</div>
	</div>
</div>
</div>
</div>
			<div id="full-col" class="fl-col fl-node-5fc6358d8db50 fl-col-small fl-col-small-full-width" data-node="5fc6358d8db50">
	<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-rich-text fl-node-633ddadca93dc" data-node="633ddadca93dc">
	<div class="fl-module-content fl-node-content">
		<div class="fl-rich-text">
	<p>Follow us on Social Media!</p>
</div>
	</div>
</div>
<div class="fl-module fl-module-icon-group fl-node-633ddadca93dd" data-node="633ddadca93dd">
	<div class="fl-module-content fl-node-content">
	<div class="fl-icon-group">
		<span class="fl-icon"><a href="#" target="_blank" rel="noopener"><i class="fab fa-facebook-square" aria-hidden="true"></i></a></span>
		<span class="fl-icon"><a href="#" target="_blank" rel="noopener"><i class="fab fa-instagram-square" aria-hidden="true"></i></a></span>
		<span class="fl-icon"><a href="#" target="_self"><i class="fab fa-youtube-square" aria-hidden="true"></i></a></span>
		<span class="fl-icon"><a href="#" target="_self"><i class="fab fa-linkedin" aria-hidden="true"></i></a></span>
	</div>
	</div>
</div>

</div>
</div>

<div id="full-col" class="fl-col fl-node-5fc6358d8db50 fl-col-small fl-col-small-full-width" data-node="5fc6358d8db50">
	<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-rich-text fl-node-633ddadca93dc" data-node="633ddadca93dc">
	<div class="fl-module-content fl-node-content">
		<div class="fl-rich-text">
	<p> We Offer</p>
</div>
	</div>
</div>
<div class="fl-module fl-module-icon-group fl-node-633ddadca93dd" data-node="633ddadca93dd">
	<div class="fl-module-content fl-node-content">
		<div class="fl-icon-group">
	
		<span class="fl-icon">
								<p>Our Laserscreed concrete flooring is renowned for its durability and precision. Utilizing advanced technology, our team ensures an even and level surface, eliminating imperfections. With its exceptional strength and longevity, Laserscreed concrete flooring is the ideal choice for industrial, commercial, and high-traffic areas.</p>
			</span>
	</div>
	</div>
</div>
</div>
</div>
	</div>
		</div>
	</div>
</div>
<div id="footer3copyright" class="fl-row fl-row-full-width fl-row-bg-color fl-node-5fc6358d8db61" data-node="5fc6358d8db61">
	<div class="fl-row-content-wrap">
		<div class="uabb-row-separator uabb-top-row-separator">
</div>
						<div class="fl-row-content fl-row-fixed-width fl-node-content">
		
<div class="fl-col-group fl-node-5fc6358d8db62 fl-col-group-equal-height fl-col-group-align-center fl-col-group-custom-width" data-node="5fc6358d8db62">
			<div class="fl-col fl-node-5fc6358d8db63" data-node="5fc6358d8db63">
	<div class="fl-col-content fl-node-content"><div class="fl-module fl-module-rich-text fl-node-5fc6358d8db5c" data-node="5fc6358d8db5c">
	<div class="fl-module-content fl-node-content">
		<div class="fl-rich-text">
	<div class="row">
<div style="" class="col-sm-5 col-md-5">
<ul class="breadcrumb">
	<li><a href="index.html"><strong>Home</strong></a></li>
 	<li><a href="profile.html"><strong>Profile</strong></a></li>                   
	<li><a href="services.html"><strong>SERVICES</strong></a></li>
	<li><a href="contacts.php"><strong>Contact Us</strong></a></li>
</ul>
</div>
<div class="col-sm-7 col-md-7">
	<p>© COPYRIGHT 2009. STA FLOORING ALL RIGHTS RESERVED</p>
</div>
</div>

</div>
	</div>
</div>
</div>
</div>
	</div>
		</div>
	</div>
</div>
</footer><div class="uabb-js-breakpoint" style="display: none;"></div>	</div><!-- .fl-page -->
<style>
			:root {
			--main-bg-color: #77b0eb;  
			--main-bor-text-color: #000;
			--main-bor-width: 3px;
			--main-bor-color: #000;
			
			--main-button-color: #195bbc;
			--main-buttontext-color: #fff;
			--main-buttonhover-color: #195bbc;
			--main-buttonhovertext-color: #fff;
					}
							
			
</style>

	
<script data-minify="1" src="assets/js/layout.js.download" id="fl-builder-layout-5-js" defer></script>

<script src="assets/js/jquery.ba-throttle-debounce.min.js.download" id="jquery-throttle-js" defer></script>

<script data-minify="1" src="assets/js/sta-layout-bundle.js.download" id="fl-builder-layout-bundle-564fa6dfb2e15fee619fc15dc896eae3-js" defer></script>

<script id="fl-automator-js-extra">
var themeopts = {"medium_breakpoint":"992","mobile_breakpoint":"768","scrollTopPosition":"800"};
</script>

<script src="assets/js/theme.min.js.download" id="fl-automator-js" defer></script>


</body></html>