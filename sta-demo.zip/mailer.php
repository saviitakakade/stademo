<?php
// ----------------------------------------- 
//  The Web Help .com
// ----------------------------------------- 
// remember to replace your@email.com with your own email address lower in this code.

// load the variables form address bar
$name = $_REQUEST["name"];
$projectnm = $_REQUEST["projectnm"];
$projectadd = $_REQUEST["projectadd"];
$mobile = $_REQUEST["mobile"];
$from = $_REQUEST["from"];
$verif_box = $_REQUEST["verif_box"];
$interested = $_REQUEST["interested"];
$comments = $_REQUEST["message"];

// remove the backslashes that normally appears when entering " or '
$name = stripslashes($name); 
$projectnm = stripslashes($projectnm); 
$projectadd = stripslashes($projectadd); 
$mobile = stripslashes($mobile); 
$from = stripslashes($from); 
$message = stripslashes($comments); 
$interested = stripslashes($interested); 

// check to see if verificaton code was correct
if(md5($verif_box).'a4xn' == $_COOKIE['tntcon']){
	// if verification code was correct send the message and show this page

	$message = "Comments: ".$comments;
	$message = "I am Interested In: ".$interested."\n".$message;
	$message = "Email: ".$from."\n".$message;
        $message = "Phone / Mobile: ".$mobile."\n".$message;
	$message = "Project Address: ".$projectadd."\n".$message;
	$message = "Project Name: ".$projectnm."\n".$message;
	$message = "Name: ".$name."\n".$message;

	mail("satshilweb@gmail.com, $from", 'Online Enquiry Form: '.$name, $_SERVER['REMOTE_ADDR']."\n\n".$message, "From: $from");
	// delete the cookie so it cannot sent again by refreshing this page
	setcookie('tntcon','');
header('Location: http://www.nocaagro.com/demo/online/index.html');
} else {
	// if verification code was incorrect then return to contact page and show error
	header("Location:".$_SERVER['HTTP_REFERER']."?name=$name&projectnm=$projectnm&projectadd=$projectadd&mobile=$mobile&from=$from&interested=$interested&message=$comments&wrong_code=true");
	exit;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PHP Contact Form Redirect</title>
</head>

<body>

<!-- This page is displayed only if there is some error -->
<?php
echo nl2br($errors);
?>


</body>
</html>
